<title>SD Muhammadiyah 3 Pontianak</title>
	<meta charset="UTF-8">
	<meta name="description" content="Naldy Project">
	<meta name="keywords" content="Naldy Project, SD Muhammadiyah Pontianak">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="{{$profil->logo_sekolah}}" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="{{url('public')}}/assets-landing/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="{{url('public')}}/assets-landing/css/font-awesome.min.css"/>
	<link rel="stylesheet" href="{{url('public')}}/assets-landing/css/themify-icons.css"/>
	<link rel="stylesheet" href="{{url('public')}}/assets-landing/css/magnific-popup.css"/>
	<link rel="stylesheet" href="{{url('public')}}/assets-landing/css/animate.css"/>
	<link rel="stylesheet" href="{{url('public')}}/assets-landing/css/owl.carousel.css"/>
	<link rel="stylesheet" href="{{url('public')}}/assets-landing/css/style.css"/>


	
