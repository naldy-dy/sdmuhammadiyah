@extends('admin.template.layout')
@section('content')
<div class="card">
	<div class="card-body">
		<h3>Selamat datang kembali</h3>
		<p>SD Muhammadiyah 3 Pontianak</p>
	</div>
</div>
@endsection