<div>
    <div class="card">
        <div class="card-body">
            {{$slot}}
        </div>
    </div>
</div>