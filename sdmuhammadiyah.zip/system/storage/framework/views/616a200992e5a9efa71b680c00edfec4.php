<!DOCTYPE html>
<html lang="en">
<head>
	<?php echo $__env->make('landing.assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- header section -->
	<?php echo $__env->make('landing.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- header section end-->


	<!-- Header section  -->
	<?php echo $__env->make('landing.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- Header section end -->


	<!-- Breadcrumb section -->
	<div class="site-breadcrumb">
		<div class="container">
			<a href="#"><i class="fa fa-home"></i> Beranda</a> <i class="fa fa-angle-right"></i>
			<span><?php echo e($title ?? ''); ?></span>
		</div>
	</div>
	<!-- Breadcrumb section end -->


	<!-- About section -->
	<section class="about-section spad pt-0">
		<div class="container">
			<div class="section-title text-center">
				<h3><?php echo e($title ?? ''); ?></h3>
			</div>
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	</section>
	<!-- About section end-->


	<!-- Footer section -->
	<?php echo $__env->make('landing.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- Footer section end-->

	


</body>
</html><?php /**PATH C:\xampp\htdocs\projek\sdmuhammadiyah\system\resources\views/landing/layout.blade.php ENDPATH**/ ?>