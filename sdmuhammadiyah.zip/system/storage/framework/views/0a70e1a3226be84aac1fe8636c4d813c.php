<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-striped table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Aksi</th>
                        <th>Nama Siswa</th>
                        <th>Jenis Kelamin</th>
                        <th>Tempat Tanggal Lahir</th>
                        <th>Umur</th>
                        <th>NIK</th>
                        <th>Agama</th>
                        <th>Alamat Lengkap</th>
                    </tr>
                </thead>

                <?php $__currentLoopData = $list_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <a href="<?php echo e(url('admin/ppdb',date('Y'))); ?>/<?php echo e($item->id); ?>" class="btn btn-dark"><i class="fa fa-eye"></i></a>
                        <a href="<?php echo e(url('admin/ppdb',date('Y'))); ?>/<?php echo e($item->id); ?>/terima" onclick="return confirm('Lanjutkan Terima')" class="btn btn-success"><i class="fa fa-check"></i></a>
                        <a href="<?php echo e(url('admin/ppdb',date('Y'))); ?>/<?php echo e($item->id); ?>/tolak" onclick="return confirm('Lanjutkan Tolak')" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                    </td>
                    <td><?php echo e(strtoupper($item->nama_lengkap)); ?></td>
                    <td><?php echo e(ucwords($item->jenis_kelamin)); ?></td>
                    <td><?php echo e(ucwords($item->tempat_lahir)); ?>, <?php echo e(ucwords($item->tanggal_lahir)); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_lahir)->age); ?> tahun</td>
                    <td><?php echo e(ucwords($item->nik)); ?></td>
                    <td><?php echo e(ucwords($item->agama)); ?></td>
                    <td><?php echo e(ucwords($item->alamat)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek\sdmuhammadiyah\system\resources\views/admin/ppdb/index.blade.php ENDPATH**/ ?>