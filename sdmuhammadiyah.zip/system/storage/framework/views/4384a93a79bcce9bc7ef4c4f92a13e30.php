<?php

if (!function_exists('checkRouteActive')) {
    function checkRouteActive($route)
    {
        return request()->is($route) ? 'active' : '';
    }
}
?>
<ul class="menu">
    <li class="sidebar-title">Menu</li>

    <li class="sidebar-item <?php echo e(checkRouteActive('admin/beranda')); ?>">
        <a href="<?php echo e(url('admin/beranda')); ?>" class='sidebar-link'>
            <i class="bi bi-grid-fill"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <li class="sidebar-item has-sub <?php echo e(checkRouteActive('admin/data-sekolah*')); ?>">
        <a href="#" class='sidebar-link'>
            <i class="bi bi-stack"></i>
            <span>Data Sekolah</span>
        </a>
        <ul class="submenu">
            <li class="submenu-item <?php echo e(checkRouteActive('admin/data-sekolah/siswa')); ?>">
                <a href="<?php echo e(url('admin/siswa')); ?>">Data Siswa</a>
            </li>
            
            <li class="submenu-item <?php echo e(checkRouteActive('admin/guru')); ?>">
                <a href="<?php echo e(url('admin/guru')); ?>">Data Guru</a>
            </li>
        </ul>
    </li>

    <li class="sidebar-item has-sub <?php echo e(checkRouteActive('admin/program*')); ?>">
        <a href="#" class='sidebar-link'>
            <i class="bi bi-stack"></i>
            <span>Program Sekolah</span>
        </a>
        <ul class="submenu">
            <li class="submenu-item <?php echo e(checkRouteActive('admin/program-unggulan')); ?>">
                <a href="<?php echo e(url('admin/program-unggulan')); ?>">Program Unggulan</a>
            </li>
            <li class="submenu-item <?php echo e(checkRouteActive('admin/extrakurikuler')); ?>">
                <a href="<?php echo e(url('admin/extrakurikuler')); ?>">Extrakurikuler</a>
            </li>
            <li class="submenu-item <?php echo e(checkRouteActive('admin/sarana-prasarana')); ?>">
                <a href="<?php echo e(url('admin/sarana-prasarana')); ?>">Sarana & Prasarana</a>
            </li>
            <li class="submenu-item <?php echo e(checkRouteActive('admin/kalender-akademik',date('Y'))); ?>">
                <a href="<?php echo e(url('admin/kalender-akademik',date('Y'))); ?>">Kalender Akademik</a>
            </li>
        </ul>
    </li>

    <li class="sidebar-item has-sub <?php echo e(checkRouteActive('admin/media*')); ?>">
        <a href="#" class='sidebar-link'>
            <i class="bi bi-collection-fill"></i>
            <span>Media</span>
        </a>
        <ul class="submenu">
        <li class="submenu-item <?php echo e(checkRouteActive('admin/galeri')); ?>">
                <a href="<?php echo e(url('admin/galeri')); ?>">Galeri Kegiatan</a>
            </li>

            <li class="submenu-item <?php echo e(checkRouteActive('admin/siswa-berprestasi')); ?>">
                <a href="<?php echo e(url('admin/siswa-berprestasi')); ?>">Siswa Berprestasi</a>
            </li>

            <li class="submenu-item <?php echo e(checkRouteActive('admin/slider')); ?>">
                <a href="<?php echo e(url('admin/slider')); ?>">Slide Website</a>
            </li>
        </ul>
    </li>

    <li class="sidebar-item has-sub <?php echo e(checkRouteActive('admin/berita*')); ?>">
        <a href="#" class='sidebar-link'>
            <i class="bi bi-grid-1x2-fill"></i>
            <span>Publikasi</span>
        </a>
        <ul class="submenu">
            <li class="submenu-item <?php echo e(checkRouteActive('admin/berita')); ?>">
                <a href="<?php echo e(url('admin/berita')); ?>">Berita</a>
            </li>
            <li class="submenu-item <?php echo e(checkRouteActive('admin/artikel')); ?>">
                <a href="<?php echo e(url('admin/artikel')); ?>">Artikel</a>
            </li>
            <li class="submenu-item <?php echo e(checkRouteActive('admin/informasi')); ?>">
                <a href="<?php echo e(url('admin/informasi')); ?>">Informasi</a>
            </li>
        </ul>
    </li>

    <li class="sidebar-item has-sub <?php echo e(checkRouteActive('admin/ppdb*')); ?>">
        <a href="#" class='sidebar-link'>
            <i class="bi bi-grid-1x2-fill"></i>
            <span>PPDB</span>
        </a>
        <ul class="submenu">
            <li class="submenu-item <?php echo e(checkRouteActive('admin/ppdb')); ?>">
                <a href="<?php echo e(url('admin/ppdb', date('Y'))); ?>">Data Penerimaan Siswa</a>
            </li>
            <li class="submenu-item <?php echo e(checkRouteActive('admin/ppdb/config')); ?>">
                <a href="<?php echo e(url('admin/ppdb/config')); ?>">Config PPDB</a>
            </li>
        </ul>
    </li>

    <li class="sidebar-item <?php echo e(checkRouteActive('admin/profil-sekolah*')); ?>">
        <a href="<?php echo e(url('admin/profil-sekolah')); ?>" class='sidebar-link'>
            <i class="bi bi-file-earmark-medical-fill"></i>
            <span>Profil Sekolah</span>
        </a>
    </li>

    <li class="sidebar-item <?php echo e(checkRouteActive('admin/profil-akun')); ?>">
        <a href="<?php echo e(url('admin/profil-akun')); ?>" class='sidebar-link'>
            <i class="bi bi-people-fill"></i>
            <span>Profil Akun</span>
        </a>
    </li>
</ul>
<?php /**PATH C:\xampp\htdocs\projek\sdmuhammadiyah\system\resources\views/admin/template/sidebar.blade.php ENDPATH**/ ?>