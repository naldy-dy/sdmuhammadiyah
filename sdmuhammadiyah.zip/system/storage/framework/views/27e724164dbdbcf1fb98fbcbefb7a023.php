<header class="header-section">
		<div class="container">
			<!-- logo -->
			<a href="<?php echo e(url('/')); ?>" class="site-logo"><img src="<?php echo e($profil->logo_sekolah ?? ''); ?>" width="250px" alt=""></a>
			<div class="nav-switch">
				<i class="fa fa-bars"></i>
			</div>
			<div class="header-info">
				<div class="hf-item">
					<i class="fa fa-clock-o"></i>
					<p><span>Waktu Pelajaran:</span><?php echo e($profil->waktu_pelajaran ?? ''); ?></p>
				</div>
				<div class="hf-item">
					<i class="fa fa-map-marker"></i>
					<p><span>Alamat:</span><?php echo e(Str::limit($profil->alamat_lengkap ?? '',50)); ?></p>
				</div>
			</div>
		</div>
	</header><?php /**PATH C:\xampp\htdocs\projek\sdmuhammadiyah\system\resources\views/landing/header.blade.php ENDPATH**/ ?>