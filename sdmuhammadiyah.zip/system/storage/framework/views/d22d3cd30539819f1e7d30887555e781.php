<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-4">
    <img src="<?php echo e($profil->foto_kepsek); ?>" width="100%" alt="">
    </div>

    <div class="col-md-8">
        <?php echo nl2br($profil->sambutan_kepsek); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('landing.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek\sdmuhammadiyah\system\resources\views/landing/sambutan-kepsek.blade.php ENDPATH**/ ?>