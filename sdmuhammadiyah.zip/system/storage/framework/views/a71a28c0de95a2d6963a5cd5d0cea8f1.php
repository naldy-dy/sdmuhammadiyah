<?php $__env->startSection('content'); ?>
<button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg"> <i class="fa fa-upload"></i> Upload Foto
	</button>

	<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Upload Slider</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal">
					</button>
				</div>
				<div class="modal-body">
					<form action="" method="post" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<div class="row">
							<div class="col-md-12 mb-3">
								<span>Judul Slider</span>
								<input type="text" required name="judul" class="form-control">
							</div>

							<div class="col-md-6 mb-3">
								<div class="form-group">
									<span>Gambar : </span>
									<input type="file" class="form-control mb-3" required name="foto" accept="image/*" onchange="previewImage(event, this)">
								</div>
							</div>

                            <div class="col-md-6 mb-3">
								<center>
									<img id="imagePreview" src="" alt="Preview Gambar" style="max-width: 50%; display: none;">
								</center>
							</div>

                            <div class="col-md-12 mb-3">
                                <span>Deskripsi</span>
                                <textarea name="deskripsi" class="form-control" id=""></textarea>
                            </div>

							

							

							<div class="col-md-12">
								<button class="btn btn-primary" type="submit">Upload</button>
							</div>

						</div>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger light" data-bs-dismiss="modal"> Close</button>
				</div>
			</div>
		</div>
	</div>


   <?php $__currentLoopData = $list_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="card mb-3">
    <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <img src="<?php echo e(url($item->foto)); ?>" width="100%" alt="">
            </div>
            <div class="col-md-8">
                <b><?php echo e(ucwords($item->judul)); ?></b> <br>
                <?php echo e($item->deskripsi); ?> <br><br>

                <a href="<?php echo e(url('admin/slider',$item->id)); ?>/delete" onclick="return confirm('Hapus data?')" class="btn btn-danger"><i class="fa fa-trash"></i></a>
            </div>
        </div>
    </div>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   <div class="col-md-12">
    <?php echo e($list_slider->links()); ?>

   </div>



    


    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

<script type="text/javascript">
	var i = 0;

	$("#add_form").click(function() {
		++i;

    // Membuat ID unik untuk setiap elemen gambar dan input file
		var addForm = `
		<div class="row" id="form_${i}">
		<div class="col-md-6 mb-3">
		<div class="form-group">
		<span>Gambar: </span>
		<input type="file" class="form-control" required name="foto[]" accept="image/*" onchange="previewImage(event, this)">
		</div>
		</div>

		<div class="col-md-6">
		<center>
		<img id="imagePreview_${i}" src="" alt="Preview Gambar" style="max-width: 50%; display: none;">
		</center>
		</div>

		<div class="col-md-12">
		<button type="button" class="btn btn-danger btn-sm remove-form">Hapus</button>
		</div>
		</div>
		`;

		$("#dynamicForm").append(addForm);
	});

	function previewImage(event, inputElement) {
		var reader = new FileReader();
		reader.onload = function() {
			var output = inputElement.closest('.row').querySelector('img');
			output.src = reader.result;
			output.style.display = 'block';
		};
		reader.readAsDataURL(event.target.files[0]);
	}

  // Menghapus form yang sudah ditambahkan
	$(document).on('click', '.remove-form', function() {
		$(this).closest('.row').remove();
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek\sdmuhammadiyah\system\resources\views/admin/media/slider/index.blade.php ENDPATH**/ ?>