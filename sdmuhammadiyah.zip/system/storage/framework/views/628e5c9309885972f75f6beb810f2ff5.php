<?php $__env->startSection('content'); ?>
<button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg"> <i class="fa fa-plus"></i> Buka PPDB Sekolah
	</button>

	<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">PPDB Sekolah</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal">
					</button>
				</div>
				<div class="modal-body">
					<form action="" method="post" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<div class="row">
							<div class="col-md-12 mb-3">
								<span>Tanggal Pembukaan</span>
								<input type="date" required name="tanggal_mulai" class="form-control">
							</div>

							<div class="col-md-12 mb-3">
								<span>Tanggal Penutupan</span>
								<input type="date" required name="tanggal_selesai" class="form-control">
							</div>

							

							<div class="col-md-12">
								<button class="btn btn-primary" type="submit">Buka PPDB</button>
							</div>

						</div>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger light" data-bs-dismiss="modal"> Close</button>
				</div>
			</div>
		</div>
	</div>


	<div class="card">
		<div class="card-body">
			<table class="table table-bordered table-hover table-striped">
				<thead>
					<tr>
						<th>No</th>
						<th>Tahun Pembukaan</th>
						<th>Status PPDB</th>
						<th>Tanggal Pembukaan</th>
						<th>Tanggal Penutupan</th>
						<th>Aksi</th>
					</tr>
				</thead>

				<?php $__currentLoopData = $list_ppdb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($item->ppdb_tahun); ?></td>
					<td>
						<?php if($item->ppdb_status == 1): ?>
							<span class="btn btn-success">Buka</span>
						<?php elseif($item->ppdb_status == 0): ?>
							<span class="btn btn-danger">Tutup</span>
						<?php endif; ?>
					</td>
					<td><?php echo e($item->tanggal_mulai); ?></td>
					<td><?php echo e($item->tanggal_selesai); ?></td>
					<td>
						<a href="" class="btn btn-danger"> Tutup PPDB</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>




   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek\sdmuhammadiyah\system\resources\views/admin/ppdb/config.blade.php ENDPATH**/ ?>