
<?php $__env->startSection('content'); ?>


<div class="card">
	<div class="card-body">
		<h3 class="text-danger">Ganti Password</h3>
		<form action="<?php echo e(url('admin/profil-akun/ganti-password')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="mb-3 col-md-6">
					<span>Password Baru</span>
					<input type="password" class="form-control" name="new" minlength="5" placeholder="New Password">
				</div>
				<div class="mb-3 col-md-6">
					<span>Konfirmasi Password Baru</span>
					<input type="password" class="form-control" name="confirm" minlength="5" placeholder="Confirm New Password">
				</div>

				<div class="mb-3 col-md-12">
					<button class="btn btn-danger float-right"><i class="fa fa-key"></i> Ganti Password</button>
				</div>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek\sdmuhammadiyah\system\resources\views/admin/profil-akun.blade.php ENDPATH**/ ?>