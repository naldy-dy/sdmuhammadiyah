<?php $__env->startSection('content'); ?>

<div class="card mb-3">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h3><?php echo e($title ?? ''); ?></h3>
            <a href="<?php echo e(url('admin/profil-sekolah/edit')); ?>" class="btn btn-primary"><i class="fa fa-pencil-alt"></i> Update Profil</a>
        </div>

    </div>
</div>


<div class="card">
    <div class="card-body">
        <div class="row">
           
            <div class="col-md-6 mb-5">
                <b class="text-primary">Tentang</b><hr><br>
                 <img src="<?php echo e(url($profil->gambar_utama ?? '')); ?>" width="100%" alt="">
                <?php echo nl2br($profil->tentang ?? ''); ?>

            </div>

             <div class="col-md-6 mb-5">
                <b class="text-primary">Sambutan Kepala Sekolah</b><hr><br>
               <p>
                   <img src="<?php echo e(url($profil->foto_kepsek)); ?>" width="200px" alt="">
                   <?php echo nl2br($profil->sambutan_kepsek); ?>

               </p>
            </div>


            <div class="col-md-6 mb-5">
                <b class="text-primary">Visi</b><hr><br>
                <?php echo nl2br($profil->visi); ?>

            </div>
            <div class="col-md-6 mb-5">
                <b class="text-primary">Visi</b><hr><br>
                <?php echo nl2br($profil->misi); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek\sdmuhammadiyah\system\resources\views/admin/profil-sekolah/index.blade.php ENDPATH**/ ?>