<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $list_sarana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="card mb-3">
    <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <img src="<?php echo e(url($item->foto)); ?>" width="100%" alt="">
            </div>
            <div class="col-md-8">
                <b><?php echo e(ucwords($item->sarana)); ?></b> <br>
                <?php echo nl2br($item->deskripsi); ?> <br><br>

                
            </div>
        </div>
    </div>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   <div class="col-md-12">
    <?php echo e($list_sarana->links()); ?>

   </div>

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('landing.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek\sdmuhammadiyah\system\resources\views/landing/sarana.blade.php ENDPATH**/ ?>