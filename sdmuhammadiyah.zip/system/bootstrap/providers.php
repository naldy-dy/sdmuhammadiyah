<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\CostumProfider::class,
    App\Providers\CostumProvider::class,
];
